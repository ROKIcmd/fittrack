# Trainer pages (dashboard + 4 new pages)

Copy everything in `src/` into your `frontend/src/` (same folder names, files replace the old ones):

```
src/components/TrainerShell.jsx          (updated: pending-request badge, nav hover)
src/components/trainer/TrainerUI.jsx     Card, Pill, Button, TextButton, Label, TextInput, TextArea,
                                         SearchInput, SelectInput, Notice, CountUp, UploadBox, Divider
src/components/trainer/PlanLibrary.jsx   left panel shared by Workout + Diet
src/components/trainer/PlanEditorFrame.jsx right card frame shared by Workout + Diet
src/components/trainer/AnimatedLineChart.jsx  animated SVG chart (no library)
src/data/trainerStore.js                 shared in-memory data (see note)
src/data/trainerDashboard.js             (unchanged)
src/pages/Trainer/TrainerDashboard.jsx   (updated: live data from the store)
src/pages/Trainer/TrainerWorkoutPlans.jsx
src/pages/Trainer/TrainerDietPlans.jsx
src/pages/Trainer/TrainerRescheduling.jsx
src/pages/Trainer/TrainerBodyMetrics.jsx
```

## App.jsx routes

```jsx
import TrainerDashboard from "./pages/Trainer/TrainerDashboard";
import TrainerWorkoutPlans from "./pages/Trainer/TrainerWorkoutPlans";
import TrainerDietPlans from "./pages/Trainer/TrainerDietPlans";
import TrainerRescheduling from "./pages/Trainer/TrainerRescheduling";
import TrainerBodyMetrics from "./pages/Trainer/TrainerBodyMetrics";

<Route path="/trainer/dashboard" element={<TrainerDashboard />} />
<Route path="/trainer/workout-plans" element={<TrainerWorkoutPlans />} />
<Route path="/trainer/diet-plans" element={<TrainerDietPlans />} />
<Route path="/trainer/rescheduling" element={<TrainerRescheduling />} />
<Route path="/trainer/body-metrics" element={<TrainerBodyMetrics />} />
{/* /trainer/schedule stays your Placeholder */}
```
(Wrap them in the same protected-route element your dashboard route already uses.)

## Notes
- No new dependencies and no new global CSS. The pages use the `animate-*` classes already in your `index.css`;
  the chart carries its own scoped keyframes. Everything animated is off under `prefers-reduced-motion`.
- `trainerStore.js` is in-memory: refresh resets it to the Figma sample data. Nothing is sent to a backend.
